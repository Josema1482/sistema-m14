// app.js

let tareas = JSON.parse(localStorage.getItem("tareas")) || [];

function guardarLocal() {
    localStorage.setItem(
        "tareas",
        JSON.stringify(tareas)
    );
}

function generarID() {
    return Date.now();
}

function agregarHistorial(tarea, texto) {

    if (!tarea.historial) {
        tarea.historial = [];
    }

    tarea.historial.push({
        fecha: new Date().toLocaleString(),
        texto
    });
}

function guardarTarea() {

    const archivosInput =
        document.getElementById("archivo");

    let archivosBase64 = [];

    if (archivosInput.files.length > 0) {

        let pendientes =
            archivosInput.files.length;

        Array.from(archivosInput.files)
            .forEach(file => {

                const reader =
                    new FileReader();

                reader.onload = function (e) {

                    archivosBase64.push({

                        nombre: file.name,

                        archivo: e.target.result
                    });

                    pendientes--;

                    if (pendientes === 0) {

                        crearTarea(
                            archivosBase64
                        );
                    }
                };

                reader.readAsDataURL(file);
            });

    } else {

        crearTarea([]);
    }
}

function crearTarea(adjuntos) {

    const tarea = {

        id: generarID(),

        fechaCreacion:
            new Date()
                .toLocaleString(),

        fijada:
            document.getElementById("fijada").checked,

        categoria:
            document.getElementById("categoria").value,

        esperandoRespuesta:
            document.getElementById("esperandoRespuesta").value,

        proveedor:
            document.getElementById("proveedor").value,

        pedidoPor:
            document.getElementById("pedidoPor").value,

        descripcion:
            document.getElementById("descripcion").value,

        prioridad:
            document.getElementById("prioridad").value,

        fechaInicio:
            document.getElementById("fechaInicio").value,

        fechaNecesidad:
            document.getElementById("fechaNecesidad").value,

        fechaCumplimiento: "",

        estado: "Pendiente",

        comentarios: [],

        historial: [],

        adjuntos,

        recurrente:
            document.getElementById("recurrente").value
    };

    agregarHistorial(
        tarea,
        "Tarea creada"
    );

    tareas.push(tarea);

    guardarLocal();

    render();

    bootstrap.Modal.getInstance(
        document.getElementById("modalNueva")
    ).hide();

    limpiar();
}

function limpiar() {

    [
        "proveedor",
        "pedidoPor",
        "descripcion",
        "fechaInicio",
        "fechaNecesidad"
    ].forEach(id => {

        document.getElementById(id).value = "";
    });

    document.getElementById("archivo").value = "";

    document.getElementById("fijada").checked = false;
}

function calcularDias(fecha) {

    if (!fecha) return "-";

    const inicio = new Date(fecha);

    const hoy = new Date();

    return Math.floor(
        (hoy - inicio)
        /
        (1000 * 60 * 60 * 24)
    );
}

function render() {

    const tabla =
        document.getElementById("tablaTareas");

    tabla.innerHTML = "";

    const buscar =
        document.getElementById("buscar")
            .value
            .toLowerCase();

    const filtroEstado =
        document.getElementById("filtroEstado")
            .value;

    const filtroCategoria =
        document.getElementById("filtroCategoria")
            ?.value || "";

    const filtroPrioridad =
        document.getElementById("filtroPrioridad")
            ?.value || "";

    let pendientes = 0;
    let proceso = 0;
    let vencidas = 0;
    let finalizadas = 0;

    tareas.sort((a, b) =>
        b.fijada - a.fijada
    );

    tareas.forEach(t => {

        const textoBusqueda = `
            ${t.descripcion}
            ${t.pedidoPor}
            ${t.proveedor}
            ${t.categoria}
        `.toLowerCase();

        if (
            !textoBusqueda.includes(buscar)
        ) {
            return;
        }

        if (
            filtroEstado &&
            t.estado !== filtroEstado
        ) {
            return;
        }

        if (
            filtroCategoria &&
            t.categoria !== filtroCategoria
        ) {
            return;
        }

        if (
            filtroPrioridad &&
            t.prioridad !== filtroPrioridad
        ) {
            return;
        }

        if (t.estado === "Pendiente")
            pendientes++;

        if (t.estado === "En proceso")
            proceso++;

        if (t.estado === "Finalizada")
            finalizadas++;

        let claseFecha = "";

        if (
            t.fechaNecesidad &&
            t.estado !== "Finalizada"
        ) {

            const hoy = new Date();

            const necesidad =
                new Date(t.fechaNecesidad);

            const diff =
                Math.ceil(
                    (necesidad - hoy)
                    /
                    (1000 * 60 * 60 * 24)
                );

            if (diff < 0) {

                claseFecha = "vencida";

                vencidas++;
            }

            if (diff === 0) {

                claseFecha = "vence-hoy";
            }
        }

        tabla.innerHTML += `

        <tr class="
            prioridad-${t.prioridad.toLowerCase()}
            ${claseFecha}
        ">

            <td>
                ${t.fijada ? "📌" : ""}
                ${t.id}
            </td>

            <td>
                <span class="badge bg-secondary">
                    ${t.estado}
                </span>
            </td>

            <td>${t.prioridad}</td>

            <td>${t.categoria || "-"}</td>

            <td>${t.esperandoRespuesta || "-"}</td>

            <td>${t.proveedor || "-"}</td>

            <td>${t.pedidoPor}</td>

            <td>${t.descripcion}</td>

            <td>${t.fechaNecesidad || "-"}</td>

            <td>
                ${calcularDias(t.fechaInicio)}
            </td>

            <td>

                <button
                    class="btn btn-sm btn-primary"
                    onclick="abrirDetalle(${t.id})">

                    Ver

                </button>

            </td>

        </tr>
        `;
    });

    document.getElementById("cantPendientes")
        .innerText = pendientes;

    document.getElementById("cantProceso")
        .innerText = proceso;

    document.getElementById("cantVencidas")
        .innerText = vencidas;

    document.getElementById("cantFinalizadas")
        .innerText = finalizadas;
}

function abrirDetalle(id) {

    const t =
        tareas.find(x => x.id === id);

    let comentariosHTML = "";

    t.comentarios.forEach(c => {

        comentariosHTML += `

        <div class="comment mb-2">

            <small>
                ${c.fecha}
            </small>

            <div>
                ${c.texto}
            </div>

        </div>
        `;
    });

    let adjuntosHTML = "";

    if (t.adjuntos) {

        t.adjuntos.forEach(a => {

            adjuntosHTML += `

            <a
                href="${a.archivo}"
                download="${a.nombre}"
                class="btn btn-outline-secondary btn-sm me-2 mb-2">

                ${a.nombre}

            </a>
            `;
        });
    }

    document.getElementById("detalleContenido")
        .innerHTML = `

    <div class="row">

    <div class="col-md-6">

    <p>
        <b>Creada:</b>
        ${t.fechaCreacion || "-"}
    </p>

    <p>
        <b>Estado:</b>
        ${t.estado}
    </p>

    <p>
        <b>Fecha cumplimiento:</b>
        ${t.fechaCumplimiento || "-"}
    </p>

    <p>
        <b>Categoría:</b>
        ${t.categoria}
    </p>

    <p>
        <b>Esperando respuesta:</b>
        ${t.esperandoRespuesta}
    </p>

    <p>
        <b>Proveedor:</b>
        ${t.proveedor}
    </p>

    <p>
        <b>Pedido por:</b>
        ${t.pedidoPor}
    </p>

    <p>
        <b>Prioridad:</b>
        ${t.prioridad}
    </p>

    <p>
        <b>Descripción:</b>
        ${t.descripcion}
    </p>

    <label>Estado</label>

    <select
        id="editEstado"
        class="form-select mb-3">

        <option ${
            t.estado === "Pendiente"
                ? "selected"
                : ""
        }>
            Pendiente
        </option>

        <option ${
            t.estado === "En proceso"
                ? "selected"
                : ""
        }>
            En proceso
        </option>

        <option ${
            t.estado === "Esperando proveedor"
                ? "selected"
                : ""
        }>
            Esperando proveedor
        </option>

        <option ${
            t.estado === "Finalizada"
                ? "selected"
                : ""
        }>
            Finalizada
        </option>

    </select>

    <div class="form-check mb-3">

        <input
            class="form-check-input"
            type="checkbox"
            id="editFijada"
            ${
                t.fijada
                    ? "checked"
                    : ""
            }>

        <label class="form-check-label">

            Fijar tarea

        </label>

    </div>

    <button
        class="btn btn-success mb-3"
        onclick="guardarEdicion(${t.id})">

        Guardar cambios

    </button>

    <hr>

    <h5>Adjuntos</h5>

    ${adjuntosHTML || "Sin adjuntos"}

    <hr>

    <button
        class="btn btn-danger"
        onclick="confirmarEliminar(${t.id})">

        Eliminar

    </button>

    </div>

    <div class="col-md-6">

    <h5>Comentarios</h5>

    ${comentariosHTML}

    <textarea
        id="nuevoComentario"
        class="form-control"
        rows="3"></textarea>

    <button
        class="btn btn-primary mt-2"
        onclick="agregarComentario(${t.id})">

        Agregar comentario

    </button>

    </div>

    </div>
    `;

    new bootstrap.Modal(
        document.getElementById("modalDetalle")
    ).show();
}

function guardarEdicion(id) {

    const tarea =
        tareas.find(t => t.id === id);

    const nuevoEstado =
        document.getElementById("editEstado").value;

    if (
        nuevoEstado === "Finalizada"
        &&
        !tarea.fechaCumplimiento
    ) {

        tarea.fechaCumplimiento =
            new Date()
                .toLocaleString();
    }

    tarea.estado = nuevoEstado;

    tarea.fijada =
        document.getElementById("editFijada").checked;

    agregarHistorial(
        tarea,
        "Tarea editada"
    );

    guardarLocal();

    abrirDetalle(id);

    render();
}

function agregarComentario(id) {

    const texto =
        document.getElementById("nuevoComentario")
            .value;

    if (!texto) return;

    const tarea =
        tareas.find(t => t.id === id);

    tarea.comentarios.push({

        fecha:
            new Date()
                .toLocaleString(),

        texto
    });

    guardarLocal();

    abrirDetalle(id);

    render();
}

function confirmarEliminar(id) {

    const modalHTML = `

    <div class="modal fade"
        id="modalEliminar"
        tabindex="-1">

        <div class="modal-dialog modal-dialog-centered">

            <div class="modal-content">

                <div class="modal-header bg-danger text-white">

                    <h5 class="modal-title">
                        Confirmar eliminación
                    </h5>

                </div>

                <div class="modal-body">

                    ¿Eliminar esta tarea?

                </div>

                <div class="modal-footer">

                    <button
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">

                        Cancelar

                    </button>

                    <button
                        class="btn btn-danger"
                        onclick="eliminarTarea(${id})">

                        Eliminar

                    </button>

                </div>

            </div>

        </div>

    </div>
    `;

    const existente =
        document.getElementById("modalEliminar");

    if (existente) {
        existente.remove();
    }

    document.body.insertAdjacentHTML(
        "beforeend",
        modalHTML
    );

    const modal = new bootstrap.Modal(
        document.getElementById("modalEliminar")
    );

    modal.show();
}

function eliminarTarea(id) {

    tareas = tareas.filter(
        t => t.id !== id
    );

    guardarLocal();

    bootstrap.Modal.getInstance(
        document.getElementById("modalEliminar")
    )?.hide();

    bootstrap.Modal.getInstance(
        document.getElementById("modalDetalle")
    )?.hide();

    render();
}

function exportarBackup() {

    const blob = new Blob(
        [JSON.stringify(tareas)],
        { type: "application/json" }
    );

    const a =
        document.createElement("a");

    a.href =
        URL.createObjectURL(blob);

    a.download =
        "backup_tareas.json";

    a.click();
}

function exportarPDF() {
    window.print();
}

function exportarExcel() {

    const datos = tareas.map(t => ({

        ID: t.id,

        Estado: t.estado,

        Prioridad: t.prioridad,

        Categoria: t.categoria,

        EsperandoRespuesta:
            t.esperandoRespuesta,

        Proveedor: t.proveedor,

        PedidoPor: t.pedidoPor,

        Descripcion: t.descripcion,

        Inicio: t.fechaInicio,

        Necesidad: t.fechaNecesidad,

        Cumplimiento:
            t.fechaCumplimiento
    }));

    const ws =
        XLSX.utils.json_to_sheet(datos);

    const wb =
        XLSX.utils.book_new();

    XLSX.utils.book_append_sheet(
        wb,
        ws,
        "Tareas"
    );

    XLSX.writeFile(
        wb,
        "tareas.xlsx"
    );
}

function toggleDarkMode() {
    document.body.classList.toggle("dark");
}

document.getElementById("buscar")
    ?.addEventListener(
        "keyup",
        render
    );

document.getElementById("filtroEstado")
    ?.addEventListener(
        "change",
        render
    );

document.getElementById("filtroCategoria")
    ?.addEventListener(
        "change",
        render
    );

document.getElementById("filtroPrioridad")
    ?.addEventListener(
        "change",
        render
    );

render();